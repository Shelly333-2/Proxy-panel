# Functions for editing the minecraft config
# XXX plugin manager

BEGIN { push(@INC, ".."); };
use strict;
use warnings;
no warnings 'redefine';
no warnings 'uninitialized';
use WebminCore;
use Time::Local;
use POSIX;
&init_config();
our ($module_root_directory, %text, %gconfig, $root_directory, %config,
     $module_name, $remote_user, $base_remote_user, $gpgpath,
     $module_config_directory, @lang_order_list, @root_directories,
     $module_config_file);
our $history_file = "$module_config_directory/history.txt";
our $download_page_url = "https://www.minecraft.net/en-us/download/server";
our $playtime_dir = "$module_config_directory/playtime";
our $uuid_cache_file = "$module_config_directory/uuids";

&foreign_require("webmin");

# get_minecraft_jar()
# Returns the path to the JAR file
sub get_minecraft_jar
{
if ($config{'minecraft_jar'} && $config{'minecraft_jar'} =~ /^\//) {
	return $config{'minecraft_jar'};
	}
elsif ($config{'minecraft_jar'}) {
	return $config{'minecraft_dir'}."/".$config{'minecraft_jar'};
	}
else {
	return $config{'minecraft_dir'}."/"."minecraft_server.jar";
	}
}

# check_minecraft_server()
# Returns an error message if the Minecraft server is not installed
sub check_minecraft_server
{
-d $config{'minecraft_dir'} ||
	return &text('check_edir', $config{'minecraft_dir'});
my $jar = &get_minecraft_jar();
-r $jar ||
	return &text('check_ejar', $jar);
&has_command($config{'java_cmd'}) ||
	return &text('check_ejava', $config{'java_cmd'});
return undef;
}

# is_minecraft_port_in_use()
# If any server is using the default Minecraft port or looks like it is running
# minecraft_server.jar, return the PID.
sub is_minecraft_port_in_use
{
&foreign_require("proc");
my $port = $config{'port'} || 25565;
my ($pid) = &proc::find_socket_processes("tcp:".$port);
return $pid if ($pid);
my @procs = &proc::list_processes();
my $jar = &get_minecraft_jar();
foreach my $p (@procs) {
	if ($p->{'args'} =~ /^java.*\Q$jar\E/) {
		return $p->{'pid'};
		}
	}
return undef;
}

# is_minecraft_server_running()
# If the minecraft server is running, return the PID
sub is_minecraft_server_running
{
&foreign_require("proc");
my @procs = &proc::list_processes();
my $jar = &get_minecraft_jar();
my $shortjar = $jar;
$shortjar =~ s/^.*\///;
foreach my $p (@procs) {
	if ($p->{'args'} =~ /^\S*\Q$config{'java_cmd'}\E.*\Q$jar\E/) {
		return $p->{'pid'};
		}
	}
return undef;
}

# is_any_minecraft_server_running()
# If the server is runnign for ANY version of Minecraft, return the PID
sub is_any_minecraft_server_running
{
&foreign_require("proc");
my @procs = &proc::list_processes();
my $dir = $config{'minecraft_dir'};
my $jar = &get_minecraft_jar();

# Prefer the default version
foreach my $p (@procs) {
	if ($p->{'args'} =~ /^\S*\Q$config{'java_cmd'}\E.*\Q$jar\E/) {
		my $ver = $jar =~ /([0-9\.]+)\.jar$/ ? $1 : undef;
		return wantarray ? ($p->{'pid'}, $ver, $jar) : $p->{'pid'};
		}
	}

# Look for other versions
foreach my $p (@procs) {
	if ($p->{'args'} =~ /^\S*\Q$config{'java_cmd'}\E.*(\Q$dir\E\S+\.jar)/) {
		my $jar = $1;
		my $ver = $jar =~ /([0-9\.]+)\.jar$/ ? $1 : undef;
		return wantarray ? ($p->{'pid'}, $ver, $jar) : $p->{'pid'};
		}
	}
return wantarray ? ( ) : undef;
}

sub get_minecraft_config_file
{
return $config{'minecraft_dir'}."/velocity.toml";
}

# get_minecraft_config()
# Parses the config into an array ref of hash refs
sub get_minecraft_config
{
my @rv;
my $fh = "CONFIG";
my $lnum = 0;
&open_readfile($fh, &get_minecraft_config_file()) || return [ ];
while(<$fh>) {
	s/\r|\n//g;
	s/#.*$//;
	if (/^([^=]+)=(.*)/) {
		push(@rv, { 'name' => $1,
			    'value' => $2,
			    'line' => $lnum });
		}
	$lnum++;
	}
close($fh);
return \@rv;
}

# find(name, &config)
# Returns all objects with some name in the config
sub find
{
my ($name, $conf) = @_;
my @rv = grep { lc($_->{'name'}) eq lc($name) } @$conf;
return wantarray ? @rv : $rv[0];
}

# find_value(name, &config)
# Returns the values of all objects with some name in the config
sub find_value
{
my ($name, $conf) = @_;
my @rv = map { $_->{'value'} } &find($name, $conf);
return wantarray ? @rv : $rv[0];
}

# save_directive(name, value, &config)
# Update one directive in the config
sub save_directive
{
my ($name, $value, $conf) = @_;
my $old = &find($name, $conf);
my $lref = &read_file_lines(&get_minecraft_config_file());
if ($old && defined($value)) {
	# Update existing line
	$lref->[$old->{'line'}] = $name." =".$value;
	$old->{'value'} = $value;
	}
elsif ($old && !defined($value)) {
	# Delete existing line
	splice(@$lref, $old->{'line'}, 1);
	my $idx = &indexof($old, @$conf);
	splice(@$conf, $idx, 1) if ($idx >= 0);
	foreach my $c (@$conf) {
		if ($c->{'line'} > $old->{'line'}) {
			$c->{'line'}--;
			}
		}
	}
elsif (!$old && defined($value)) {
	# Add new line
	my $n = { 'name' => $name,
		  'value' => $value,
		  'line' => scalar(@$lref) };
	push(@$lref, $name." = ".$value);
	push(@$conf, $n);
	}
}

# get_start_command([suffix])
# Returns a command to start the server
sub get_start_command
{
my ($suffix) = @_;
my $jar = &get_minecraft_jar();
my $ififo = &get_input_fifo();
my $rv = "(test -e ".$ififo." || mkfifo ".$ififo.") ; ".
	 "cd ".$config{'minecraft_dir'}." && ".
	 "(tail -f ".$ififo." | ".
	 $config{'java_envs'}." ".
	 &has_command($config{'java_cmd'})." ".
	 $config{'java_args'}." ".
	 " -jar ".$jar." nogui ".
	 $config{'jar_args'}." ".
	 ">> server.out 2>&1 )";
$rv .= " ".$suffix if ($suffix);
if ($config{'unix_user'} ne 'root') {
	$rv = &command_as_user($config{'unix_user'}, 0, $rv);
	}
return $rv;
}

sub get_input_fifo
{
return $config{'minecraft_dir'}."/input.fifo";
}

# start_minecraft_server()
# Launch the minecraft server in the background
sub start_minecraft_server
{
# Mark EULA as accepted
my $eula = $config{'minecraft_dir'}."/eula.txt";
my $lref = &read_file_lines($eula);
my $changed = 0;
foreach my $l (@$lref) {
	if ($l =~ /eula=false/) {
		$l =~ s/false/true/;
		$changed++;
		}
	}
if ($changed) {
	&flush_file_lines($eula);
	}
else {
	&unflush_file_lines($eula);
	}

my $cmd = &get_start_command();
my $pidfile = &get_pid_file();
&unlink_file($pidfile);
&system_logged("$cmd &");
sleep(1);
my $pid = &is_minecraft_server_running();
if (!$pid) {
	my $out = &backquote_command(
		"tail -2 ".$config{'minecraft_dir'}."/server.out");
	return $out || "Unknown error - no output produced";
	}
my $fh = "PID";
&open_tempfile($fh, ">$pidfile");
&print_tempfile($fh, $pid."\n");
&close_tempfile($fh);
&set_ownership_permissions($config{'unix_user'}, undef, undef, $pidfile);
return undef;
}

# stop_minecraft_server([other-version])
# Kill the server, if running
sub stop_minecraft_server
{
my ($any) = @_;
my $func = $any ? \&is_any_minecraft_server_running
		: \&is_minecraft_server_running;
my $pid = &$func();
$pid || return "Not running!";

# Try graceful shutdown
&send_server_command("stop");
for(my $i=0; $i<10; $i++) {
	last if (!&$func());
	sleep(1);
	}

# Clean kill
if (&$func()) {
	kill('TERM', $pid);
	for(my $i=0; $i<10; $i++) {
		last if (!&$func());
		sleep(1);
		}
	}

# Fatal kill
if (&$func()) {
	kill('KILL', $pid);
	}

# Clean up FIFO tailer
my $fpid = int(&backquote_command("fuser ".&get_input_fifo()." 2>/dev/null"));
if ($fpid) {
	kill('TERM', $fpid);
	}
return undef;
}

# send_server_command(command, [no-log])
# Just sends a command to the server
sub send_server_command
{
my ($cmd, $nolog) = @_;
my $ififo = &get_input_fifo();
my $fh = "FIFO";
&open_tempfile($fh, ">$ififo", 1, 1, 1);
&print_tempfile($fh, $cmd."\n");
&close_tempfile($fh);
if (!$nolog) {
	&additional_log('minecraft', 'server', $cmd);
	}
}

# get_minecraft_log_file()
sub get_minecraft_log_file
{
my $newfile = $config{'minecraft_dir'}."/logs/latest.log";
if (-r $newfile) {
	return $newfile;
	}
else {
	return $config{'minecraft_dir'}."/server.log";
	}
}

# execute_minecraft_command(command, [no-log], [wait-time])
# Run a command, and return output from the server log
sub execute_minecraft_command
{
my ($cmd, $nolog, $wait) = @_;
$cmd =~ s/^\///;	# Leading / is now obsolete
$wait ||= 100;
my $logfile = &get_minecraft_log_file();
my $fh = "LOG";
&open_readfile($fh, $logfile);
seek($fh, 0, 2);
my $pos = tell($fh);
&send_server_command($cmd, $nolog);
for(my $i=0; $i<$wait; $i++) {
	select(undef, undef, undef, 0.1);
	my @st = stat($logfile);
	last if ($st[7] > $pos);
	}
my $out;
while(<$fh>) {
	$out .= $_;
	}
close($fh);
return wantarray ? split(/\r?\n/, $out) : $out;
}

# get_command_history()
# Returns the history of commands run
sub get_command_history
{
my $lref = &read_file_lines($history_file);
return @$lref;
}

# save_command_history(&commands)
sub save_command_history
{
my ($cmds) = @_;
my $lref = &read_file_lines($history_file);
@$lref = @$cmds;
&flush_file_lines($history_file);
}

# get_login_logout_times(player)
# Returns the last login IP, time, X, Y, Z, logout time (if any) and list of
# recent events.
sub get_login_logout_times
{
my ($name) = @_;
my ($ip, $intime, $xx, $yy, $zz, $outtime);
my $logfile = &get_minecraft_log_file();
my @events;
my @files = ( $logfile );
if ($logfile =~ /^(.*)\/latest.log$/) {
	# New server version keeps old rotated log files in gzip format
	my $dir = $1;
	my @extras;
	opendir(DIR, $dir);
	foreach my $f (readdir(DIR)) {
		if ($f =~ /^(\d+\-\d+\-\d+-\d+)\.log\.gz$/) {
			push(@extras, $f);
			}
		}
	closedir(DIR);
	@extras = sort { $a cmp $b } @extras;
	unshift(@files, map { "$dir/$_" } @extras);

	# To avoid reading too much, limit to newest 100k of logs
	my @small;
	my $total = 0;
	foreach my $f (reverse(@files)) {
		push(@small, $f);
		my @st = stat($f);
		$total += $st[7];
		last if ($total > 100000);
		}
	@files = reverse(@small);
	}
foreach my $f (@files) {
	my $fh = "TAIL";
	if ($f =~ /\/latest.log$/) {
		# Latest log, read all of it
		&open_readfile($fh, $f);
		}
	elsif ($f =~ /\.gz$/) {
		# Read whole compressed log
		&open_execute_command($fh, "gunzip -c $f", 1, 1);
		}
	else {
		# Old single log file, read only the last 10k lines
		&open_execute_command($fh, "tail -10000 $f", 1, 1);
		}

	my @tm = localtime(time());
	while(<$fh>) {
		my ($y, $mo, $d, $h, $m, $s, $msg);
		if (/^(\d+)\-(\d+)\-(\d+)\s+(\d+):(\d+):(\d+)\s+\[\S+\]\s+(.*)/) {
			# Old log format
			($y, $mo, $d, $h, $m, $s, $msg) = ($1, $2, $3, $4, $5, $6, $7);
			}
		elsif (/^\[(\d+):(\d+):(\d+)\]\s+\[[^\[]+\]:\s*(.*)/) {
			# New log format
			($h, $m, $s, $msg) = ($1, $2, $3, $4);
			if ($f =~ /\/(\d+)\-(\d+)\-(\d+)/) {
				# Get date from old rotated log
				($y, $mo, $d) = ($1, $2, $3);
				}
			else {
				# Assume latest.log, which is for today
				($y, $mo, $d) = ($tm[5]+1900, $tm[4]+1, $tm[3]);
				}
			}
		else {
			next;
			}
		if ($msg =~ /^\Q$name\E\[.*\/([0-9\.]+):(\d+)\]\s+logged\s+in.*\((\-?[0-9\.]+),\s+(\-?[0-9\.]+),\s+(\-?[0-9\.]+)\)/) {
			# Login message
			$ip = $1;
			($xx, $yy, $zz) = ($3, $4, $5);
			$intime = &parse_log_time($y, $m, $d, $h, $mo, $s);
			}
		elsif ($msg =~ /^\Q$name\E\s+(\[.*\]\s+)?lost/ ||
		       $msg =~ /^Disconnecting\s+\Q$name\E/) {
			# Logout message
			$outtime = &parse_log_time($y, $m, $d, $h, $mo, $s);
			}
		elsif ($msg =~ /^(\S+\s+)?\Q$name\E(\s|\[)/) {
			# Some player event
			push(@events,
			   { 'time' => &parse_log_time($y, $m, $d, $h, $mo, $s),
			     'msg' => $msg });
			}
		}
	close($fh);
	}

sub parse_log_time
{
my ($y, $m, $d, $h, $mo, $s) = @_;
return timelocal($s, $m, $h, $d, $mo-1, $y-1900);
}

# md5_checksum(file)
# Returns a checksum for a file
sub md5_checksum
{
my ($file) = @_;
&has_command("md5sum") || &error("md5sum command not installed!");
return undef if (!-r $file);
my $out = &backquote_command("md5sum ".quotemeta($file));
return $out =~ /^([a-f0-9]+)\s/ ? $1 : undef;
}

# get_pid_file()
# Returns the file in which the server PID is stored
sub get_pid_file
{
return $config{'minecraft_dir'}."/server.pid";
}

# update_init_script_args(&args)
# Updates all Java command-line args in the init script
sub update_init_script_args
{
my ($args) = @_;
my $mode;
&foreign_require("init");
if (defined(&init::get_action_mode)) {
	$mode = &init::get_action_mode($config{'init_name'});
	}
$mode ||= $init::init_mode;

# Find the init script file
my $file;
if ($mode eq "init") {
	$file = &init::action_filename($config{'init_name'});
	}
elsif ($mode eq "upstart") {
	$file = "/etc/init/$config{'init_name'}.conf";
	}
elsif ($mode eq "systemd") {
	my $unit = $config{'init_name'};
	$unit .= ".service" if ($unit !~ /\.service$/);
	$file = &init::get_systemd_root($config{'init_name'})."/".$unit;
	}
elsif ($mode eq "local") {
	$file = "$init::module_config_directory/$config{'init_name'}.sh";
	}
elsif ($mode eq "osx") {
	my $ucfirst = ucfirst($config{'init_name'});
	$file = "$init::config{'darwin_setup'}/$ucfirst/$init::config{'plist'}";
	}
elsif ($mode eq "rc") {
	my @dirs = split(/\s+/, $init::config{'rc_dir'});
	$file = $dirs[$#dirs]."/".$config{'init_name'}.".sh";
	}
else {
	return 0;
	}
return 0 if (!-r $file);	# Not enabled?

# Find and edit the Java command
&lock_file($file);
my $lref = &read_file_lines($file);
my $found = 0;
foreach my $l (@$lref) {
	if ($l =~ /^(.*su.*-c\s+)(.*)/) {
		# May be wrapped in an su command
		my $su = $1;
		my $cmd = &unquotemeta($2);
		if ($cmd =~ /^(.*\Q$config{'java_cmd'}\E)\s+(.*)(-jar.*)/) {
			$cmd = $1." ".$args." ".$3;
			$l = $su.quotemeta($cmd);
			$found = 1;
			}
		}
	elsif ($l =~ /^(.*\Q$config{'java_cmd'}\E)\s+(.*)(-jar.*)/) {
		$l = $1." ".$args." ".$3;
		$found = 1;
		}
	}
&flush_file_lines($file);
&unlock_file($file);

return $found;
}

sub unquotemeta
{
my ($str) = @_;
eval("\$str = \"$str\"");
return $str;
}

}
1;